README:

This is an example run where the cattle population has been increased by 1000x.

Changes compared to the baseline in blue include largely less water available, as the cattle imposes a large water need.